MSCQR Connector Windows transport diagnostics test package

Version: 2026.6.11
Trust: unsigned internal/test package metadata placeholder

This package advertises the connector release contract used by CI and staging while a signed Windows installer is published through the signed connector release workflow.
Do not present this package as a signed production installer.
Production Windows rollout should use a signed MSCQR Connector installer from the signed release workflow.
