import React, { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams, Link } from "react-router-dom";
import apiClient from "@/lib/api-client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { AlertTriangle, CheckCircle2, QrCode, ArrowLeft, RefreshCw } from "lucide-react";
import { format } from "date-fns";

type VerifyResponse = {
  isAuthentic: boolean;
  message: string;
  code: string;
  status?: string;

  licensee?: string | null;
  licenseePrefix?: string | null;

  productBatch?: {
    id: string;
    productName: string;
    productCode?: string | null;
    description?: string | null;
    serialStart?: number | null;
    serialEnd?: number | null;
    serialFormat?: string | null;
    printedAt?: string | null;
    manufacturer?: { id: string; name: string; email: string } | null;
    parentBatch?: { id: string; name: string } | null;
  } | null;

  batchName?: string | null;
  printedAt?: string | null;

  firstScanned?: string | null;
  scanCount?: number;
  isFirstScan?: boolean;
  warningMessage?: string | null;
};

function prettyDate(iso?: string | null) {
  if (!iso) return "—";
  try {
    return format(new Date(iso), "MMM d, yyyy • HH:mm");
  } catch {
    return iso;
  }
}

export default function Verify() {
  const { code } = useParams();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<VerifyResponse | null>(null);

  const normalizedCode = useMemo(() => String(code || "").trim(), [code]);

  const load = async () => {
    if (!normalizedCode) {
      setError("Missing code");
      setData(null);
      setLoading(false);
      return;
    }

    setLoading(true);
    setError(null);
    setData(null);

    const res = await apiClient.verifyQRCode(normalizedCode);

    if (!res.success) {
      setError(res.error || "Verification service unavailable");
      setLoading(false);
      return;
    }

    // support both direct data payloads and { data: { ... } }
    const payload: any = res.data;
    const dto: VerifyResponse = (payload && payload.isAuthentic !== undefined)
      ? (payload as VerifyResponse)
      : (payload?.data as VerifyResponse);

    if (!dto || typeof dto.isAuthentic !== "boolean") {
      setError("Unexpected response from server");
      setLoading(false);
      return;
    }

    setData(dto);
    setLoading(false);
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [normalizedCode]);

  const statusBadge = (d: VerifyResponse) => {
    if (d.isAuthentic) {
      return (
        <Badge className="bg-success/10 text-success">
          <CheckCircle2 className="mr-1 h-4 w-4" /> Authentic
        </Badge>
      );
    }
    return (
      <Badge className="bg-destructive/10 text-destructive">
        <AlertTriangle className="mr-1 h-4 w-4" /> Not authentic
      </Badge>
    );
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-3xl mx-auto px-4 py-8 space-y-6">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" onClick={() => navigate(-1)}>
              <ArrowLeft className="mr-2 h-4 w-4" /> Back
            </Button>
            <div className="flex items-center gap-2">
              <QrCode className="h-5 w-5" />
              <h1 className="text-2xl font-bold">Verify QR</h1>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={load} disabled={loading}>
              <RefreshCw className="mr-2 h-4 w-4" /> Refresh
            </Button>
            <Button size="sm" asChild>
              <Link to="/verify">Scan another</Link>
            </Button>
          </div>
        </div>

        <Card>
          <CardHeader className="pb-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <CardTitle className="text-lg">Result</CardTitle>
                <p className="text-sm text-muted-foreground break-all">Code: {normalizedCode.toUpperCase()}</p>
              </div>
              {data ? statusBadge(data) : null}
            </div>
          </CardHeader>

          <CardContent className="space-y-4">
            {loading ? (
              <div className="text-sm text-muted-foreground">Verifying…</div>
            ) : error ? (
              <div className="rounded-md border border-destructive/30 bg-destructive/5 p-3 text-sm text-destructive">
                {error}
              </div>
            ) : !data ? (
              <div className="text-sm text-muted-foreground">No data.</div>
            ) : (
              <>
                <div className="text-sm">
                  <div className="font-medium">{data.message}</div>
                  {data.status && !data.isAuthentic && (
                    <div className="text-muted-foreground">Status: {String(data.status)}</div>
                  )}
                  {data.warningMessage && (
                    <div className="mt-2 rounded-md border border-amber-500/30 bg-amber-500/10 p-3 text-amber-800 dark:text-amber-200 text-sm">
                      {data.warningMessage}
                    </div>
                  )}
                </div>

                <Separator />

                <div className="grid gap-4 sm:grid-cols-2 text-sm">
                  <div>
                    <div className="text-muted-foreground">Licensee</div>
                    <div className="font-medium">{data.licensee || "—"}</div>
                    {data.licenseePrefix ? (
                      <div className="text-xs text-muted-foreground">Prefix: {data.licenseePrefix}</div>
                    ) : null}
                  </div>

                  <div>
                    <div className="text-muted-foreground">Printed at</div>
                    <div className="font-medium">{prettyDate(data.printedAt)}</div>
                  </div>

                  <div>
                    <div className="text-muted-foreground">First scanned</div>
                    <div className="font-medium">{prettyDate(data.firstScanned)}</div>
                  </div>

                  <div>
                    <div className="text-muted-foreground">Scan count</div>
                    <div className="font-medium">{typeof data.scanCount === "number" ? data.scanCount : "—"}</div>
                    {typeof data.isFirstScan === "boolean" ? (
                      <div className="text-xs text-muted-foreground">{data.isFirstScan ? "First scan" : "Scanned before"}</div>
                    ) : null}
                  </div>
                </div>

                {data.productBatch ? (
                  <>
                    <Separator />

                    <div className="space-y-2">
                      <div className="text-sm font-medium">Product details</div>

                      <div className="rounded-md border p-3 space-y-2 text-sm">
                        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                          <div>
                            <div className="font-medium">{data.productBatch.productName}</div>
                            <div className="text-xs text-muted-foreground font-mono">
                              {data.productBatch.productCode || "—"}
                            </div>
                          </div>

                          {data.productBatch.printedAt ? (
                            <Badge className="bg-success/10 text-success">Printed</Badge>
                          ) : (
                            <Badge className="bg-muted text-muted-foreground">Not printed</Badge>
                          )}
                        </div>

                        {data.productBatch.description ? (
                          <div className="text-muted-foreground">{data.productBatch.description}</div>
                        ) : null}

                        <div className="grid gap-3 sm:grid-cols-2">
                          <div>
                            <div className="text-muted-foreground">Serial range</div>
                            <div className="font-medium">
                              {data.productBatch.serialStart ?? "—"} → {data.productBatch.serialEnd ?? "—"}
                            </div>
                            {data.productBatch.serialFormat ? (
                              <div className="text-xs text-muted-foreground font-mono">{data.productBatch.serialFormat}</div>
                            ) : null}
                          </div>

                          <div>
                            <div className="text-muted-foreground">Manufacturer</div>
                            <div className="font-medium">{data.productBatch.manufacturer?.name || "—"}</div>
                            {data.productBatch.manufacturer?.email ? (
                              <div className="text-xs text-muted-foreground">{data.productBatch.manufacturer.email}</div>
                            ) : null}
                          </div>
                        </div>

                        {data.productBatch.parentBatch?.name ? (
                          <div className="text-xs text-muted-foreground">
                            Parent batch: <span className="font-mono">{data.productBatch.parentBatch.name}</span>
                          </div>
                        ) : null}
                      </div>
                    </div>
                  </>
                ) : data.batchName ? (
                  <>
                    <Separator />
                    <div className="text-sm">
                      <div className="text-sm font-medium">Batch</div>
                      <div className="text-muted-foreground">{data.batchName}</div>
                    </div>
                  </>
                ) : null}
              </>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
